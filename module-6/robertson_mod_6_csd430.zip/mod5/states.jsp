<%@ page import="beans.StateBean" %>
<%@ page import="java.util.ArrayList" %>

<%
    StateBean stateBean = new StateBean();
    ArrayList<Integer> ids = stateBean.getStateIds();

    String selectedId = request.getParameter("stateId");

    if (selectedId != null) {
        int id = Integer.parseInt(selectedId);
        stateBean.getStateById(id);
    }
%>

<!DOCTYPE html>
<html>
<head>
    <title>Rashai States Data</title>
</head>
<body>

<h1>Rashai States Database</h1>

<p>
    This page displays state information from the MySQL database named CSD430.
    Select a state ID from the dropdown menu to view one full record.
</p>

<form method="post" action="states.jsp">
    <label for="stateId">Select State ID:</label>

    <select name="stateId" id="stateId">
        <%
            for (Integer id : ids) {
        %>
            <option value="<%= id %>"><%= id %></option>
        <%
            }
        %>
    </select>

    <input type="submit" value="Display Record">
</form>

<%
    if (selectedId != null) {
%>

<h2>Selected State Record</h2>

<table border="1">
    <thead>
        <tr>
            <th>State ID</th>
            <th>State Name</th>
            <th>Abbreviation</th>
            <th>Capital</th>
            <th>Population</th>
            <th>Region</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td><%= stateBean.getStateId() %></td>
            <td><%= stateBean.getStateName() %></td>
            <td><%= stateBean.getAbbreviation() %></td>
            <td><%= stateBean.getCapital() %></td>
            <td><%= stateBean.getPopulation() %></td>
            <td><%= stateBean.getRegion() %></td>
        </tr>
    </tbody>
</table>

<%
    }
%>

</body>
</html>