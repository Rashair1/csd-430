package model;

import java.io.Serializable;

/**
 * MovieBean stores movie data for display on a JSP page.
 *
 * Rashai Robertson
 * CSD430
 * Module 4: Assignment 4.2
 * June 28, 2026
 *
 * This JavaBean implements Serializable as required by the assignment.
 */
public class MovieBean implements Serializable {

    private static final long serialVersionUID = 1L;

    private String title;
    private String genre;
    private String director;
    private int releaseYear;
    private String description;

    /**
     * No-argument constructor with sample record data.
     */
    public MovieBean() {
        this.title = "Forrest Gump";
        this.genre = "Drama/Comedy";
        this.director = "Robert Zemeckis";
        this.releaseYear = 1994;
        this.description = "A story about Forrest Gump and his journey through major events in American history.";
    }

    public String getTitle() {
        return title;
    }

    public String getGenre() {
        return genre;
    }

    public String getDirector() {
        return director;
    }

    public int getReleaseYear() {
        return releaseYear;
    }

    public String getDescription() {
        return description;
    }
}
