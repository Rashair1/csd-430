<%@ page import="model.MovieBean" %>

<%
    /*
     * Scriptlet section:
     * This creates a MovieBean object.
     * The HTML below retrieves data from the bean using getter methods.
     */
    MovieBean movie = new MovieBean();
%>


<!-- 
   Rashai Robertson
   CSD430
   Module 4: Assignment 4.2
   June 28, 2026
-->

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Module 4: JavaBean Data Display</title>

    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f4f4f4;
            color: #222;
            margin: 0;
            padding: 30px;
        }

        .container {
            max-width: 900px;
            margin: auto;
            background: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.15);
        }

        h1, h2 {
            text-align: center;
        }

        .description {
            background: #eef3ff;
            border-left: 5px solid #4c6fff;
            padding: 15px;
            line-height: 1.6;
            margin: 20px 0;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 25px;
        }

        th, td {
            border: 1px solid #333;
            padding: 12px;
            text-align: left;
            vertical-align: top;
        }

        th {
            background: #222;
            color: white;
        }

        tr:nth-child(even) {
            background: #f7f7f7;
        }

        .footer {
            text-align: center;
            margin-top: 25px;
            font-size: 0.95rem;
        }
    </style>
</head>

<body>

<div class="container">

    <h1>Module 4: JavaBean Data Display</h1>
    <h2>Movie Record Information</h2>

    <div class="description">
        This JSP uses a JavaBean to store my movie data from Module 2. The JSP creates the bean
        using a scriptlet and displays the bean data in a table.
        The table includes field names, record descriptions, and values. The styling comes from a previous
        website project i worked on.
    </div>

    <table>
        <tr>
            <th>Field</th>
            <th>Record Description</th>
            <th>Value from JavaBean</th>
        </tr>

        <tr>
            <td>Title</td>
            <td>The name of the movie.</td>
            <td><%= movie.getTitle() %></td>
        </tr>

        <tr>
            <td>Genre</td>
            <td>The category or type of movie.</td>
            <td><%= movie.getGenre() %></td>
        </tr>

        <tr>
            <td>Director</td>
            <td>The person responsible for directing the movie.</td>
            <td><%= movie.getDirector() %></td>
        </tr>

        <tr>
            <td>Release Year</td>
            <td>The year the movie was released.</td>
            <td><%= movie.getReleaseYear() %></td>
        </tr>

        <tr>
            <td>Description</td>
            <td>A short summary of the movie record.</td>
            <td><%= movie.getDescription() %></td>
        </tr>
    </table>

</div>

</body>
</html>
